package ru.vaneck.sap;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.command.v2.ClientCommands;
import org.joml.Vector3f;
import ru.vaneck.sap.lib.SAP;
import ru.vaneck.sap.lib.sound.AudioType;

public class SimpleAudioPlayer implements ModInitializer {

    @Override
    public void onInitialize() {
        SimpleAudioPlayerCommon.init();

//        ClientCommandRegistrationCallback.EVENT.register((dispatcher, buildContext) -> {
//            dispatcher.register(ClientCommands.literal("play").executes(context -> {
//                SAP.play("C:\\users\\Ivan\\desktop\\cat-screams-and-disappear.ogg", AudioType.FILE, instance -> {
//                    instance.setVolume(0.25f);
//                });
//                return 0;
//            }));
//        });
    }
}
