package ru.vaneck.sap;

import org.joml.Vector3f;
import ru.vaneck.sap.lib.SAP;
import ru.vaneck.sap.lib.sound.AudioType;
import ru.vaneck.sap.platform.Services;

public class SimpleAudioPlayerCommon {

    public static void init() {
        if (Services.PLATFORM.isModLoaded("sap")) {
            SimpleAudioPlayerConstants.LOG.info("Simple Audio Player is loaded");
        }

//        SAP.playPositional("C:\\users\\Ivan\\downloads\\1397300_Maestro.mp3", AudioType.FILE, instance -> {
//            instance.setPosition(new Vector3f(-52, 85, 165));
//            instance.setVolume(0.25f);
//            instance.setMaxDistance(100.5f);
//        });

//        SAP.play("https://www.newgrounds.com/audio/download/1397300", AudioType.URL, SoundSource.RECORDS, 0.25F);
//        SAP.playStream("https://www.newgrounds.com/audio/download/1397300", AudioType.URL, SoundSource.RECORDS, 0.25F);

//        SAP.runOnSoundEngineLoaded(() -> {
//            SAP.create("C:\\users\\Ivan\\downloads\\1397300_Maestro.mp3", AudioType.FILE, false)
//                    .thenAccept(soundInstance -> {
//                        soundInstance.setSoundChannel(SoundSource.AMBIENT);
//                        soundInstance.setVolume(0.25F);
//                        soundInstance.play();
//                    })
//                    .exceptionallyAsync(throwable -> {
//                        Constants.LOG.error("Failed to create sound instance: ", throwable);
//                        return null;
//                    });
//        });

//        SAP.playPositional("path/to/file.mp3", AudioType.FILE, 0.5F, 10, 50, 10);
//
//        SAP.playPositional("path/to/file.mp3", AudioType.FILE, new Vector3f(10, 50, 10), 0.5F);
//
//        SAP.playPositional("path/to/file.mp3", AudioType.FILE, instance -> {
//            instance.setPosition(new Vec3(512, 42, 993));
//            instance.setVolume(0.75f);
//            // ...
//        });

//        SAP.play("path/to/file.mp3", AudioType.FILE, instance -> {
//            instance.setLooping(true);
//            instance.setReferenceDistance(4);
//            instance.setMaxDistance(15);
//            instance.setVolume(0.25F);
//        });

        /*
        .exceptionallyAsync(throwable -> {
            Constants.LOG.error("Exception while creating sound instance: {}", throwable.toString());
            return null;
        })
         */



//        SAP.play("C:\\Users\\Ivan\\Downloads\\Бобр.wav", AudioType.URL, SoundSource.RECORDS, 0.25F);
//        SAP.play("C:\\Users\\Ivan\\Downloads\\Бобр.wav", AudioType.URL, SoundSource.RECORDS, 0.25F);
//        SAP.play("C:\\Users\\Ivan\\Music\\music\\Tryhardninja-Follow-Me.ogg", AudioType.FILE, 0.1F);

//        new Thread(() -> {
//            while (!OpenAlUtils.isOpenAlReady())
//                Thread.onSpinWait();
//            AudioFactory.playOnce(
//                    "https://www.newgrounds.com/audio/download/1397300",
//                    AudioType.URL,
//                    false,
//                    true,
//                    instance -> {
//                        instance.setVolume(0.25F);
//                    }
//            );
//        }).start();
    }
}